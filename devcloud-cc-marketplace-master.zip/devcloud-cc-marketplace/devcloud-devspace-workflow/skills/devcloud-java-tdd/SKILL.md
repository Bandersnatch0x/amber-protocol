---
name: devcloud-java-tdd
description: Use when implementing Service layer business logic with branch conditions, before writing any production code. Triggers on new feature implementation, bug fixes, or behavior changes in Java Service methods.
---

# Java TDD（DevCloud 项目专属）

## 铁律

```
没有失败的测试，不写生产代码
```

先写代码再补测试？删掉重来。**没有例外。**

**违反规则的字面意思就是违反规则的精神。**

---

## 适用范围

| 层 | 是否做 TDD | 原因 |
|---|---|---|
| **Service**（有分支/校验/业务逻辑） | ✅ 必须 | 核心业务行为，价值最高 |
| **Controller** | ❌ 不做 | 逻辑极薄，测的是框架不是业务 |
| **Mapper / Repository** | ❌ 不做 | 需要真实 DB，属于集成测试范畴 |
| **前端 JS** | ❌ 不做 | 项目无测试运行环境（无 Jest/Karma） |

简单 CRUD Service（无分支）可直接编写，无需 TDD。

---

## 环境检查（执行前必须通过，否则跳过本 skill）

运行以下命令检查环境是否满足要求：

```bash
# 检查 JDK 21 是否可用
/usr/libexec/java_home -v 21 2>/dev/null || java -version 2>&1 | grep -o 'version "[^"]*"'
# 检查 Maven 是否可用
mvn -version 2>/dev/null | head -1
```

**判断规则：**
- JDK 21 不可用（命令无输出或版本不符）→ **跳过本 skill**，告知用户："当前环境无 JDK 21，跳过 TDD，请先编写生产代码，后续补充测试。"
- Maven 不可用 → 同上，**跳过本 skill**。
- 两者均满足 → 继续执行以下流程。

---

## 环境准备（首次运行前必须执行）

### 1. 确认 JDK 版本

项目要求 JDK 21，系统默认可能是 JDK 8。**每次运行测试前必须确认 JDK 版本**：

```bash
# 检查当前 JAVA_HOME 指向的 JDK 版本
java -version

# 如果不是 JDK 21，需要显式设置（不修改系统 JAVA_HOME）
# Mac 示例：
export JAVA_HOME=$(/usr/libexec/java_home -v 21 2>/dev/null)   # Linux: $(dirname $(dirname $(readlink -f $(which java))))
```

**规则**：所有 `mvn test` 命令必须加上 `JAVA_HOME` 环境变量前缀，确保使用 JDK 21。如果系统已默认 JDK 21 则可省略。

```bash
# ✅ 正确（显式指定 JDK 21）
JAVA_HOME=$(/usr/libexec/java_home -v 21) mvn test ...

# ❌ 错误（不指定，可能使用系统默认的 JDK 8）
mvn test ...
```

### 2. 检查 surefire 配置

首次运行测试前，检查 `pom.xml` 中 `maven-surefire-plugin` 的 `<argLine>` 是否包含 `@{argLine}` 占位符。此占位符是 JaCoCo 专用语法，若项目未配置 JaCoCo，占位符会被原样传给 JVM fork 导致崩溃。

```bash
# 检查是否存在 @{argLine}
grep -n '@{argLine}' pom.xml
```

若存在且项目未使用 JaCoCo，需要移除 `@{argLine}` 占位符，只保留 `--add-opens` 等必要的 JVM 参数。

---

## 测试框架约定

- **JUnit 5**（`@Test`、`@ExtendWith`）
- **Mockito**（`@Mock`、`@InjectMocks`、`@ExtendWith(MockitoExtension.class)`）
- **AssertJ**（`assertThat().isEqualTo()`，禁用 `assertEquals`）
- 测试类放在：`src/test/java/` 下与被测类相同的包路径，类名 `XxxServiceTest`
- 测试方法命名：`should_<期望结果>_when_<条件>()`

---

## 红绿重构循环

```dot
digraph tdd_cycle {
    rankdir=LR;
    red    [label="RED\n写一个失败测试", shape=box, style=filled, fillcolor="#ffcccc"];
    vred   [label="确认失败原因\n符合预期？", shape=diamond];
    green  [label="GREEN\n最小实现", shape=box, style=filled, fillcolor="#ccffcc"];
    vgreen [label="确认全绿？", shape=diamond];
    ref    [label="REFACTOR\n清理，不加功能", shape=box, style=filled, fillcolor="#ccccff"];
    next   [label="下一个场景", shape=ellipse];

    red -> vred;
    vred -> green [label="是"];
    vred -> red   [label="失败原因不对\n修测试"];
    green -> vgreen;
    vgreen -> ref   [label="是"];
    vgreen -> green [label="否，修实现"];
    ref -> vgreen   [label="保持绿"];
    vgreen -> next;
    next -> red;
}
```

### RED — 写一个失败测试（不写实现）

1. 从需求/HLD 提取所有业务场景（每个分支、边界、异常各一个）
2. 每次只写**一个**测试方法
3. **立即运行，必须看到 FAILURE / ERROR**

```java
@ExtendWith(MockitoExtension.class)
class TaskStatusServiceTest {

    @Mock
    private TaskRepository taskRepository;

    @InjectMocks
    private TaskStatusService taskStatusService;

    @Test
    void should_throw_exception_when_task_not_found() {
        // given
        when(taskRepository.findById(999L)).thenReturn(null);

        // when / then
        assertThatThrownBy(() -> taskStatusService.close(999L))
            .isInstanceOf(AgileException.class)
            .hasMessageContaining("任务不存在");
    }
}
```

**运行命令（看红）：**
```bash
JAVA_HOME=$(/usr/libexec/java_home -v 21) mvn test -pl . -Dtest=TaskStatusServiceTest#should_throw_exception_when_task_not_found 2>&1 | tail -20
```

确认：
- 测试**失败**（FAILURE/ERROR），不是意外通过
- 失败原因是"功能缺失"，而不是编译错误或拼写错误

### GREEN — 最小实现

写**最少**代码让测试通过，不加额外逻辑、不过度设计。

```bash
JAVA_HOME=$(/usr/libexec/java_home -v 21) mvn test -pl . -Dtest=TaskStatusServiceTest 2>&1 | tail -20
```

确认：
- 目标测试通过
- 其他测试未被破坏（BUILD SUCCESS）

### REFACTOR — 清理

绿之后才能重构：去除重复、改善命名、提取私有方法。不加新行为。

重构后再跑一次确认仍然全绿。

### 重复

为下一个业务场景写下一个失败测试，循环。

---

## 完整示例（带场景分解）

**需求：** 关闭任务时，状态须为"进行中"，否则报错；关闭成功后更新 `closedAt`。

**第一步：分解场景**
1. 任务不存在 → 抛异常
2. 任务状态不是"进行中" → 抛异常
3. 正常关闭 → closedAt 被设置

**第二步：依次红绿循环（每个场景走一轮）**

```java
// 场景 3 — 正常关闭
@Test
void should_set_closed_at_when_close_in_progress_task() {
    // given
    ApiTask task = new ApiTask();
    task.setId(1L);
    task.setStatus("IN_PROGRESS");
    when(taskRepository.findById(1L)).thenReturn(task);

    // when
    taskStatusService.close(1L);

    // then
    assertThat(task.getClosedAt()).isNotNull();
    verify(taskRepository).update(task);
}
```

---

## Red Flags — 立刻停止，重新开始

- 先写了生产代码，再补测试
- 测试一写就通过（说明在测已有行为，修测试）
- 无法解释测试为什么失败
- "这个方法太简单，不用测"
- "手动测过了，不需要写测试"
- "测试之后补也一样"
- "只是小修改，不影响"

**以上任何一条 = 删掉代码，从 RED 重新开始。**

---

## 发现 Bug 时

先写复现测试（RED），再修代码（GREEN），测试既是修复证明，也防止回归。

永远不要在没有失败测试的情况下修 Bug。

---

## 验证清单

完成编码前自检：

- [ ] 每个新 Service 方法至少有一个测试
- [ ] 每个测试都亲眼看到过失败
- [ ] 失败原因符合预期（功能缺失，非编译错误）
- [ ] 写了最小实现，没有过度设计
- [ ] 所有测试 BUILD SUCCESS
- [ ] 测试用真实对象，mock 只用于外部依赖（Repository/RPC）
- [ ] 边界条件和异常场景已覆盖
