---
name: devcloud-harness-review
description: Use when a task delivery is complete and code review has passed - reviews gaps discovered during this task and updates rule/standard files to prevent recurrence. Triggered by devcloud-task-dev step 8.
---

# Harness 回顾

每次任务完成后，复盘本次开发中暴露的规范盲区、重复干预和知识缺口，将问题转化为 Harness 的约束规则，防止下次重犯。

**核心原则**：每一个新错误都是一次改进 Harness 的机会。不要只修复问题，要让 Harness 变强。

---

## 执行步骤

### 第一步：逐一审查七类问题

> 知识图谱路径由环境变量 `KNOWLEDGE_MAP_PATH` 控制，默认 `doc/knowledge_map`。如项目无知识图谱（目录不存在），Q3/Q4/Q5/Q6 统一输出 `N/A`，跳过知识图谱相关操作。

**Q1 规范盲区**
> 本次任务中，AI 犯了错、或需要人工指正，但 `.claude/rules/` 或 `.claude/standards/` 对应文件里没有覆盖这条规则？

**Q2 重复干预**
> 同一类问题在本次任务中被人工纠正了超过一次？（说明约束措辞不够强，或规则位置不够醒目）

**Q3 知识图谱缺口**
> **先提取再比对**：
> 1. 列出本次改动涉及的所有：枚举值变更（新增/删除）、表字段新增/语义变更、API 参数变化、新增业务规则
> 2. 根据改动所属模块，定位 `${KNOWLEDGE_MAP_PATH:-doc/knowledge_map}/spec/` 下对应文件
> 3. 逐项核对知识图谱是否已覆盖上述改动点
> 4. 缺失则补充，已有则跳过

**Q4 知识图谱不一致**
> 本次任务（或前序任务）修改了某个功能的逻辑或数据结构，导致 `${KNOWLEDGE_MAP_PATH:-doc/knowledge_map}/` 中已有的描述与实际代码不一致？典型场景：
> - 枚举值列表已变更但知识图谱中仍是旧列表
> - 修改了数据库字段含义、新增了 API 参数、改变了业务规则但知识图谱未更新
> - 前序任务使某些配置项失效（state='X'），但知识图谱仍引用旧 ID
> - 代码中的硬编码检查（如 `impactConfigId === 3`）已变为死代码，但知识图谱仍描述为活跃逻辑
> 
> **执行方法同 Q3**：先列出改动清单，再打开知识图谱逐项比对。**禁止凭记忆回答 N/A，必须实际打开文件核对。**

**Q5 知识图谱检索反思**
> 处理当前任务时，应该检索到哪些知识图谱模块会更加准确或有效？反思检索策略是否覆盖了所有相关模块，是否有遗漏导致分析不充分。

**Q6 死代码/过时逻辑检测**
> 本次或前序任务是否导致某些代码逻辑变为死代码（永远不会执行）？例如：前端硬编码的 ID 检查指向已失效的配置、后端分支条件因数据变化永远走同一路径、旧版兼容代码已无调用方等。死代码不需要本次修复，但必须在知识图谱中标注为"已失效"，避免后续开发者误判。

**Q7 Skill 技能回顾**
> 回顾本次任务用到的所有**用户自定义 skill**（排除插件 skill），逐项检查：
> - 该 skill 的 SKILL.md 指令是否有模糊之处，导致执行时偏离预期？
> - 执行过程中是否出现了需要人工纠正的问题？skill 自身的规则能否防止该问题再次发生？
> - 是否有遗漏的检查项或约束，可以通过补充 SKILL.md 来固化？

### 第二步：判断并决策

- **七项全部"无"** → 在 `.claude/harness-evolution.md` 追加一行 `## YYYY-MM-DD | task#[编号] | 无更新`，直接结束
- **有需要更新的项** → 进入第三步，**必须完成所有更新后才能结束对话**

### 第三步：定位目标文件并执行更新

| 问题类型 | 目标文件 |
|---------|---------|
| 规范盲区（后端） | `.claude/rules/backend/` 对应文件，或 `.claude/standards/java/` |
| 规范盲区（前端） | `.claude/rules/frontend/` 对应文件，或 `.claude/standards/javaScript/` |
| 重复干预（任何类型） | 找到原有规则所在位置，强化措辞或将规则提升至更醒目的位置 |
| 知识图谱缺口 | `${KNOWLEDGE_MAP_PATH:-doc/knowledge_map}/` 对应模块文件 |
| 知识图谱不一致 | `${KNOWLEDGE_MAP_PATH:-doc/knowledge_map}/` 对应模块文件（修改已有描述使其与实际代码同步） |
| 死代码/过时逻辑 | `${KNOWLEDGE_MAP_PATH:-doc/knowledge_map}/` 对应模块文件（标注已失效的逻辑，记录死代码位置） |
| Skill 技能回顾 | 对应 skill 的 `SKILL.md` 文件（补充检查项、强化措辞、修复模糊指令） |

### 第四步：写入 Harness 进化日志（永久存档）

将本次更新插入到 `.claude/harness-evolution.md` 的 `<!-- 以下为自动追加的进化记录 -->` 注释行之后（最新记录在最上方）。

追加格式：

```markdown
## YYYY-MM-DD | task#[任务单号]

### 发现的问题

| 类型 | 问题描述 |
|------|---------|
| 规范盲区 | [具体描述，例如："新增方法缺少 AI-Generated 注释，规范文件未覆盖此场景"] |
| 重复干预 | [具体描述，或 N/A] |
| 知识图谱缺口 | [具体描述，或 N/A] |
| 知识图谱不一致 | [具体描述，例如："impact.md 中 ad_impact_config 的 impact_name 字段描述与简化后的实际值不一致"，或 N/A] |
| 知识图谱检索反思 | [具体描述，例如："处理影响评估相关任务时，应同时检索 agile.md（缺陷影响评估逻辑）和 scrum-taskadd-ui.md（创建时影响评估UI）"，或 N/A] |
| 死代码/过时逻辑 | [具体描述，或 N/A] |
| Skill 技能回顾 | [具体描述，例如："devcloud-pre-delivery-check 的 3.4 步指令太模糊，加载了 coding-style.md 但未逐项检查日志规范"，或 N/A] |

### 做了什么改动

| 改动文件 | 改动内容 |
|---------|---------|
| `.claude/rules/backend/constraints.md` | 新增：禁止在 Service 层直接返回 DO 对象 |
| `doc/knowledge_map/task-publish.md` | 补充：发布流程中 approval 状态机的状态转移说明 |

### 改动原因

[一句话说明根本原因，例如："AI 连续两次在 Service 层直接 return DO，导致字段泄露风险，原规范只约束了 Controller 层"]

---
```

### 第五步：在进度文件追加简短引用

在 `.claude/rules/dev-progress.md` 末尾追加：

```markdown
## Harness 更新记录

- 日期：YYYY-MM-DD
- 任务单号：[编号]
- 详见：`.claude/harness-evolution.md`
```

---

## 写规则的标准

- 措辞要**明确、可执行**：用"禁止"而非"尽量避免"，用"必须"而非"建议"
- **聚焦本次真正遇到的问题**，不要趁机批量添加假设性规则
- 知识图谱更新保持简洁：补充缺失的关键事实或典型实现样例，不写大段叙述
