#!/usr/bin/env python3
"""保存 HLD 文档到任务单
用法: python3 save.py <taskNo> <json-file>
"""

import sys
import os
import json
import urllib.request
import urllib.error


_TOKEN_MISSING = """
⚠️  未检测到研发云 Token，无法调用 API。

请按以下步骤配置后重试：

  1. 获取 Token：研发云 → 开放平台 → 我的 Token → 申请统一 Token

  2. 配置环境变量：

     Mac / Linux:
       export DEVCLOUD_TOKEN="your-token-here"    # 临时生效（仅当前终端）

       # 永久生效（写入 ~/.zshrc）——设置后需完全退出并重启 Claude Code 客户端才能识别
       echo 'export DEVCLOUD_TOKEN="your-token-here"' >> ~/.zshrc && source ~/.zshrc

     Windows PowerShell:
       $env:DEVCLOUD_TOKEN = "your-token-here"    # 临时生效（仅当前 PowerShell 窗口）

       # 永久生效（写入注册表）——设置后需完全退出并重启 Claude Code 客户端才能识别
       [Environment]::SetEnvironmentVariable("DEVCLOUD_TOKEN", "your-token-here", "User")
"""


def main():
    if len(sys.argv) < 3:
        print("错误: 参数不足", file=sys.stderr)
        print("用法: python3 save.py <taskNo> <json-file>", file=sys.stderr)
        sys.exit(1)

    task_no, json_file = sys.argv[1], sys.argv[2]
    api_base = os.environ.get('DEVCLOUD_API_BASE',
                              'https://dev.iwhalecloud.com/portal/ai-gateway/devspace/rpc/v3')
    token = os.environ.get('DEVCLOUD_TOKEN', '')

    if not token:
        print(_TOKEN_MISSING, file=sys.stderr)
        sys.exit(1)

    if not os.path.isfile(json_file):
        print(f"错误: JSON 文件不存在: {json_file}", file=sys.stderr)
        sys.exit(1)

    with open(json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    data['source'] = 'AI'

    payload = json.dumps(data, ensure_ascii=False).encode('utf-8')

    url = f"{api_base}/task/{task_no}/hld"
    print(f"正在保存 HLD 到任务单 {task_no}...")
    print(f"API: {url}")
    print(f"数据文件: {json_file}")

    req = urllib.request.Request(url, data=payload, headers={
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json'
    })

    try:
        with urllib.request.urlopen(req) as resp:
            body = json.loads(resp.read().decode('utf-8'))
            http_code = resp.status
    except urllib.error.HTTPError as e:
        body = json.loads(e.read().decode('utf-8'))
        http_code = e.code

    print(f"\nHTTP 状态码: {http_code}\n")
    print(json.dumps(body, ensure_ascii=False, indent=2))

    code = str(body.get('code', ''))
    if code in ('0', '9999'):
        task_doc_id = (body.get('data') or {}).get('taskDocId', 'N/A')
        print(f"\n✅ HLD 保存成功！taskDocId: {task_doc_id}")
    else:
        msg = body.get('msg') or body.get('message') or '未知错误'
        print(f"\n❌ HLD 保存失败: {msg}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
