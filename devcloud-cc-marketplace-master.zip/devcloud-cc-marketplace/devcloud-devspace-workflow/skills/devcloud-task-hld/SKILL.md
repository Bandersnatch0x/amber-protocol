---
name: devcloud-task-hld
description: 创建任务单的HLD（High-Level Design）文档，基于任务描述/评论 + 知识图谱 + 代码分析生成，支持用户审阅后回填到研发云系统。
---

# 任务单 HLD 生成工作流

当用户需要为任务单生成 HLD 文档时使用此技能。

## 前置检查：环境变量

调用脚本前，先执行以下命令确认 Token 已配置：

```bash
python3 -c "import os; t=os.environ.get('DEVCLOUD_TOKEN',''); print('TOKEN:', t[:len(t)//2]+'****' if t else '(未设置)')"
```

**若输出 `(未设置)`，停止并提示用户完成配置后再继续：**

> ⚠️ 未检测到 `DEVCLOUD_TOKEN`，请先配置：
>
> ```bash
> # 临时设置（重开终端后失效）
> export DEVCLOUD_TOKEN="your-token-here"
>
> # 永久写入 ~/.zshrc
> echo 'export DEVCLOUD_TOKEN="your-token-here"' >> ~/.zshrc
> source ~/.zshrc
> ```
>
> Token 获取：研发云 → 开放平台 → 我的 Token → 申请统一 Token
>
> ⚠️ 永久写入配置文件后，需完全退出并重启 Claude Code 客户端才能生效。

确认变量已设置后继续执行。

## 触发场景

- 用户说"生成 XXX 任务单的 HLD"
- 用户说"给 XXX 写 HLD"
- 用户说"给 XXX 任务创建/生成 HLD 文档"

## 完整流程

### 第一步：查询任务详情（条件执行）

**若当前会话中已通过 `devcloud-task-dev` 工作流查询过任务详情**（即内存中已有任务标题、需求描述、HLD 验收标准、projectId），跳过此步，直接使用已有信息进入第二步。

**仅在独立运行时**（非 devcloud-task-dev 工作流触发，或会话续接后无上下文），才需要调用 `devcloud-task-query`：

```bash
/devcloud-task-query <taskNo>
```

获取任务标题、类型、状态、需求描述、评论、已有 HLD/LLD 文档等基本信息。

**必须用 Read 工具读取所有下载的图片文件**（脚本会自动下载到 `/tmp/task_query_images/<taskNo>/`），图片可能包含 UI 原型、流程图等关键信息，不可跳过。

### 第二步：加载知识图谱

知识图谱路径由环境变量 `KNOWLEDGE_MAP_PATH` 控制，默认值为 `doc/knowledge_map`。如需自定义：

```bash
export KNOWLEDGE_MAP_PATH="docs/knowledge-graph"   # 示例：自定义路径
```

**执行前先探测：**

```bash
# 检查知识图谱目录是否存在
ls ${KNOWLEDGE_MAP_PATH:-doc/knowledge_map}/index.md 2>/dev/null
```

**若命令无输出（文件不存在），跳过此步：**

> ⚠️ 未找到知识图谱（`${KNOWLEDGE_MAP_PATH:-doc/knowledge_map}/index.md`），跳过知识图谱加载，直接进入第三步代码检索。

**若文件存在，** 按以下顺序检索：

1. **先读索引文件**：`${KNOWLEDGE_MAP_PATH:-doc/knowledge_map}/index.md`
2. **按关键词定位**：根据任务描述中的关键词在 index.md 中匹配相关模块
3. **按需加载规格文档**：只加载最相关的 `${KNOWLEDGE_MAP_PATH:-doc/knowledge_map}/spec/*.md` 文件
4. **必须打印已加载的知识图谱文件路径**，例如：

```
📚 已加载知识图谱文件（${KNOWLEDGE_MAP_PATH:-doc/knowledge_map}/）：
- spec/taskquery.md
- spec/patch.md
```

### 第三步：代码检索与影响分析

#### 3.1 代码检索

若知识图谱内容不足以支撑 HLD 编写（如缺少具体实现细节、接口签名、数据模型定义），则：

1. **打印信息缺口**：明确列出知识图谱未覆盖的内容
2. **直接检索代码**：无需等待用户确认，搜索相关 Controller、Service、Mapper、Entity
3. 检索范围以补全 HLD 所需信息为限，不做无目的的全量扫描

#### 3.2 调用方影响分析（有代码改动时必做）

对关键方法/枚举进行 grep 搜索，评估改动波及面：

1. **grep 搜索调用方**：对拟修改的关键 Service 方法、枚举值、Controller 端点进行全量引用搜索
2. **逐一验证语义兼容性**：新增校验逻辑是否会影响已有调用方的正常流程
3. **前端影响范围**：确认涉及的页面或组件、接口调用变化、是否需要前端配合修改

分析结果写入 `functionImpactDescription` 字段。

### 第四步：生成 HLD

综合任务描述 + 评论 + 知识图谱 + 代码检索 + 调用方影响分析结果，生成 HLD 文档。

#### HLD 字段定义

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `background` | string | 否 | 背景（根据需求描述填写，说明为什么要做这个需求） |
| `dataStructureDesign` | string | 否 | **有数据模型变更时必填**（新增表、修改字段、新增索引等） |
| `businessLogicDesign` | string | **是** | 业务逻辑设计 + 验收标准（核心必填字段，包含两部分内容） |
| `systemMaintenanceData` | string | 否 | 系统维护数据（如初始化 SQL、配置变更等） |
| `uiPrototype` | string | 否 | 用户界面原型（前端页面变化描述或交互说明） |
| `runtimeDesign` | string | 否 | 运行设计（进程/定时任务/并发控制等运行时考量） |
| `performanceDescription` | string | **是** | 是否考虑性能问题（示例值：`否`，如有则说明具体考量） |
| `withSwitch` | boolean | **是** | 是否通过开关控制（`true` / `false`） |
| `noSwitchReason` | string | 否 | 不通过开关控制时须说明原因 |
| `manualProcessing` | string | 否 | 人工处理工程（需手工操作的事项） |
| `unsolvedIssues` | string | 否 | 尚未解决的问题 |
| `deploymentAdjustment` | string | 否 | 是否需要调整部署方案（示例值：`否`） |
| `functionImpactDescription` | string | **有代码改动时必填** | 功能影响说明（对现有功能的影响范围），包含：调用方 grep 分析结果（所有受影响的调用方清单及语义兼容性结论）、前端影响范围（涉及页面/组件/接口变化） |

#### `businessLogicDesign` 内容结构

`businessLogicDesign` 是 HLD 最核心的字段，必须包含以下两部分：

**1. 业务逻辑设计**

注意：外层模板已渲染 `#### 2.2 业务逻辑设计(必填)` 标题，内容**不要重复写 `**业务逻辑设计**`**，直接写业务描述。如需细分小节用 `**核心流程**`、`**异常路径**` 等小标题。

描述业务流程、处理步骤、关键决策点、模块交互关系。结合知识图谱中已有的实现模式，说明：
- 核心业务流程（正常路径 + 异常路径）
- 涉及的后端模块（Controller/Service/Mapper）及交互方式
- 关键校验规则和边界条件
- 外部系统依赖（如有）

**2. 验收标准（必须包含）**

**3. 技术注意事项（有代码改动时必填）**

用 `**技术注意事项**` 粗体分隔。列出实现过程中需要注意的技术风险和约束：
- 并发/线程安全考量
- 现有数据兼容性风险
- 性能敏感点
- 已有调用方需要注意的兼容性约束
- 相关但超出本次范围的技术债务（如防御检查模式审查）

用 `**验收标准**` 粗体分隔即可。列出功能完成后验证是否满足需求的检查项，每条标准应可衡量、可测试：

列出功能完成后验证是否满足需求的检查项，每条标准应可衡量、可测试：
- 功能验收：正常场景下功能是否按预期工作
- 异常验收：边界条件、异常输入时的行为是否正确
- 回归验收：对已有功能是否无副作用
- 性能验收：如有性能要求，列出具体指标

#### 生成原则

- **必填字段不能为空**：`businessLogicDesign`（含验收标准）、`performanceDescription`、`withSwitch` 必须有值
- **数据模型变更**：涉及 DB 表结构变化时 `dataStructureDesign` 必须填写
- **开关控制**：`withSwitch = false` 时必须填写 `noSwitchReason`
- **验收标准不可省略**：`businessLogicDesign` 末尾必须包含验收标准章节
- **字号控制**：`businessLogicDesign` 字段内容会被嵌入外层文档模板（已用 `###`/`####` 标题），内部**禁止使用 `##` 或 `###` 级标题**，章节分隔使用 `**粗体文本**` 或 `#####`（h5级），避免与外层标题层级冲突导致字体大小不一致
- 基于已有信息客观描述，不臆测未确认的业务规则

### 第五步：用户审阅与修改

HLD 生成后**必须停止**，将完整的 HLD 内容展示给用户审阅。

- 明确告知用户："请审阅以上 HLD 内容，确认无误后将回填到任务单。如有需要修改的地方请提出。"
- 根据用户反馈进行修改
- 用户确认无误后进入第六步

### 第六步：回填 HLD 到任务单

用户确认后，将 HLD 内容写入 JSON 文件，然后调用 `save.sh` 脚本保存到研发云：

```bash
# 1. 先将 HLD JSON 写入临时文件（注意：内容中的中文引号 "" 必须替换为「」或[]，否则 JSON 解析会失败）
Write /tmp/task_hld_<taskNo>.json

# 2. 校验 JSON 格式（必须执行，不通过则修正后重新执行）
python3 -m json.tool /tmp/task_hld_<taskNo>.json

# 3. 调用保存脚本
python3 ${CLAUDE_PLUGIN_ROOT}/skills/devcloud-task-hld/scripts/save.py <taskNo> /tmp/task_hld_<taskNo>.json
```

**JSON 内容安全规则**：写入 JSON 的文本内容中**禁止**出现中文引号 `""`（U+201C/U+201D），必须替换为 `「」`、`[]` 或其他 ASCII 安全字符。此问题已多次导致服务端 JSON 解析失败（`Unexpected character 'ç'`）。

脚本返回 `code: "0"` 或 `"9999"` 即保存成功，`data.taskDocId` 为新建的文档 ID。

---

## 执行纪律

1. **知识图谱优先**：必须先读 `index.md`，再按需加载规格文档，最后才检索代码
2. **必填字段不可为空**：`businessLogicDesign`（含验收标准、技术注意事项）、`performanceDescription`、`withSwitch` 三者必须有值；有代码改动时 `functionImpactDescription` 必须填写
3. **等待用户审阅**：生成 HLD 后必须暂停，未经用户确认不得回填
4. **图片不可跳过**：devcloud-task-query 下载的图片必须用 Read 工具查看，可能包含关键信息
5. **调用方分析不可跳过**：有代码改动时必须 grep 关键方法/枚举的调用方，结果写入 `functionImpactDescription`