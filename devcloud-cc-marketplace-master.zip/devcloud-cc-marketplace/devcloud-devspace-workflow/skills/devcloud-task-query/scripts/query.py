#!/usr/bin/env python3
"""查询研发云任务单基本信息
用法: python3 query.py <taskNo>
"""

import sys
import os
import json
import re
import tempfile
import urllib.request
import urllib.error
from pathlib import Path


def resolve_url(src, cos_endpoint):
    if not src:
        return None
    src = src.replace('${tenantCosEndpoint}', cos_endpoint)
    if src.startswith('/'):
        src = cos_endpoint + src
    return src if src.startswith('http') else None


def extract_text_from_node(node, cos_endpoint):
    """从富文本 JSON 节点递归提取纯文本"""
    if isinstance(node, dict):
        if node.get('type') == 'image':
            src = node.get('attrs', {}).get('src', '')
            url = resolve_url(src, cos_endpoint)
            return f"\n[图片: {url}]\n" if url else ''
        if 'text' in node:
            return str(node['text'])
        return ''.join(
            extract_text_from_node(v, cos_endpoint)
            for v in node.values() if isinstance(v, (dict, list))
        )
    if isinstance(node, list):
        return ''.join(extract_text_from_node(item, cos_endpoint) for item in node)
    return ''


def parse_rich_text(text, cos_endpoint):
    if not text:
        return ''
    stripped = text.strip()
    if stripped.startswith('{'):
        try:
            return extract_text_from_node(json.loads(stripped), cos_endpoint)
        except Exception:
            pass
    return text.replace('${tenantCosEndpoint}', cos_endpoint)


def collect_image_urls(data, cos_endpoint):
    urls = []
    d = data.get('data', {})

    def find_images(node):
        if isinstance(node, dict):
            if node.get('type') == 'image':
                url = resolve_url(node.get('attrs', {}).get('src', ''), cos_endpoint)
                if url:
                    urls.append(url)
            for v in node.values():
                find_images(v)
        elif isinstance(node, list):
            for item in node:
                find_images(item)

    def parse(text):
        if not text:
            return
        stripped = text.strip()
        if stripped.startswith('{'):
            try:
                find_images(json.loads(stripped))
                return
            except Exception:
                pass
        for m in re.finditer(r'!\[.*?\]\((.*?)\)', text):
            url = resolve_url(m.group(1), cos_endpoint)
            if url:
                urls.append(url)

    parse(d.get('apiTask', {}).get('comments', ''))
    for a in d.get('taskActionDtoList', []):
        parse(a.get('adTaskAction', {}).get('comments', ''))
    for doc in d.get('taskDocDtoList', []):
        parse(doc.get('adTaskDoc', {}).get('content', ''))

    return list(dict.fromkeys(urls))  # 去重保序


_TOKEN_MISSING = """
⚠️  未检测到研发云 Token，无法调用 API。

请按以下步骤配置后重试：

  1. 获取 Token：研发云 → 开放平台 → 我的 Token → 申请统一 Token

  2. 配置环境变量：

     Mac / Linux:
       export DEVCLOUD_TOKEN="your-token-here"    # 临时生效（仅当前终端）

       # 永久生效（写入 ~/.zshrc）——设置后需完全退出并重启 Claude Code 客户端才能识别
       echo 'export DEVCLOUD_TOKEN="your-token-here"' >> ~/.zshrc && source ~/.zshrc

     Windows PowerShell:
       $env:DEVCLOUD_TOKEN = "your-token-here"    # 临时生效（仅当前 PowerShell 窗口）

       # 永久生效（写入注册表）——设置后需完全退出并重启 Claude Code 客户端才能识别
       [Environment]::SetEnvironmentVariable("DEVCLOUD_TOKEN", "your-token-here", "User")
"""


def main():
    if len(sys.argv) < 2:
        print("错误: 请提供任务单号", file=sys.stderr)
        print("用法: python3 query.py <taskNo>", file=sys.stderr)
        sys.exit(1)

    task_no = sys.argv[1]
    api_base = os.environ.get('DEVCLOUD_API_BASE',
                              'https://dev.iwhalecloud.com/portal/ai-gateway/devspace/rpc/v3')
    token = os.environ.get('DEVCLOUD_TOKEN', '')
    cos_endpoint = 'https://dev.iwhalecloud.com'

    if not token:
        print(_TOKEN_MISSING, file=sys.stderr)
        sys.exit(1)

    url = f"{api_base}/task/task-no/{task_no}"
    payload = json.dumps({
        "withTaskFlowStage": "true", "withOwnerUser": "false",
        "withProductModule": "false", "withAction": "true",
        "withParent": "false", "withTaskDoc": "true",
        "withDevCase": "false", "withTestCase": "false",
        "withTaskType": "true", "withBranchVersion": "false",
        "withAttach": "false", "withEdo": "false",
        "withTaskImpact": "false", "withConfig": "false",
        "withAllTaskType": "false"
    }).encode('utf-8')

    req = urllib.request.Request(url, data=payload, headers={
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json'
    })

    try:
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        print(f"❌ 请求失败: HTTP {e.code}", file=sys.stderr)
        sys.exit(1)

    if not data.get('data'):
        print(f"❌ 查询失败: {data.get('msg', '未知错误')}")
        sys.exit(1)

    d = data['data']
    task = d.get('apiTask', {})
    sep = '━' * 40

    print("📋 任务单信息")
    print(sep)
    print(f"任务单号: {task.get('taskNo', 'N/A')}")
    print(f"任务标题: {task.get('taskTitle', 'N/A')}")
    print(f"任务类型: {d.get('taskTypeDto', {}).get('name', 'N/A')}")
    print(f"项目空间ID: {task.get('projectId', 'N/A')}")
    print(f"当前状态: {d.get('apiTaskFlowStage', {}).get('stageName', 'N/A')}")
    print(f"创建时间: {task.get('createdDate', 'N/A')}")
    print(f"创建人: {d.get('createUserDto', {}).get('displayName', 'N/A')}")
    print(f"截止时间: {task.get('endDate', 'N/A')}")
    print(sep)
    print(f"需求描述:\n{parse_rich_text(task.get('comments') or '无描述', cos_endpoint)}")

    docs = d.get('taskDocDtoList', [])
    if docs:
        print(f"\n{sep}\n📄 HLD&LLD 文档:")
        for doc in docs:
            ad = doc.get('adTaskDoc', {})
            user = doc.get('createUserDto', {})
            content = parse_rich_text(ad.get('content', '') or '', cos_endpoint)
            print(f"{ad.get('docType', '未知类型')} — {user.get('displayName', '未知用户')} {ad.get('createdDate', 'N/A')}")
            print(content)

    action_comments = [a for a in d.get('taskActionDtoList', []) if a.get('comment')]
    if action_comments:
        print(f"\n{sep}\n💬 评论列表:")
        for action in action_comments:
            ad = action.get('adTaskAction', {})
            user = action.get('createUserDto', {})
            print(f"[{ad.get('createdDate', 'N/A')}] {user.get('displayName', '未知用户')}:")
            print(parse_rich_text(ad.get('comments', '') or '', cos_endpoint))

    img_urls = collect_image_urls(data, cos_endpoint)
    if img_urls:
        img_dir = Path(tempfile.gettempdir()) / 'task_query_images' / task_no
        img_dir.mkdir(parents=True, exist_ok=True)
        print(f"\n{sep}\n🖼️  图片文件（使用 Read 工具查看）:")
        for img_url in img_urls:
            filename = img_url.split('/')[-1].split('?')[0]
            local_path = img_dir / filename
            try:
                urllib.request.urlretrieve(img_url, local_path)
                print(f"  {local_path}")
            except Exception:
                pass


if __name__ == '__main__':
    main()
