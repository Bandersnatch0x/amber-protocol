---
name: devcloud-task-query
description: 查询浩鲸研发云任务单的基本信息，包括任务标题、分类、创建时间、需求描述、HLD/LLD文档等。
---

# 查询任务单基本信息

当用户需要查询任务单信息时使用此技能。支持通过任务单号查询任务标题、分类、创建时间、需求描述、HLD/LLD文档、项目空间ID等基本信息。

## 前置检查：环境变量

调用脚本前，先执行以下命令确认 Token 已配置：

```bash
python3 -c "import os; t=os.environ.get('DEVCLOUD_TOKEN',''); print('TOKEN:', t[:len(t)//2]+'****' if t else '(未设置)')"
```

**若输出 `(未设置)`，停止并提示用户完成配置后再继续：**

> ⚠️ 未检测到 `DEVCLOUD_TOKEN`，请先配置：
>
> ```bash
> # 临时设置（重开终端后失效）
> export DEVCLOUD_TOKEN="your-token-here"
>
> # 永久写入 ~/.zshrc
> echo 'export DEVCLOUD_TOKEN="your-token-here"' >> ~/.zshrc
> source ~/.zshrc
> ```
>
> Token 获取：研发云 → 开放平台 → 我的 Token → 申请统一 Token
>
> ⚠️ 永久写入配置文件后，需完全退出并重启 Claude Code 客户端才能生效。

确认变量已设置后继续执行。

## 触发场景

- 用户说"查询任务单 XXX"
- 用户说"看一下 XXX 这个任务单的信息"
- 用户说"XXX 任务单是什么内容"

## 使用方法

将 `<taskNo>` 替换为实际任务单号：

```bash
python3 ${CLAUDE_PLUGIN_ROOT}/skills/devcloud-task-query/scripts/query.py <taskNo>
```

## 图片读取（必须）

脚本执行后会自动从需求描述、评论、HLD/LLD 文档中提取图片，下载到系统临时目录（Mac/Linux 为 `/tmp/task_query_images/<taskNo>/`，Windows 为 `%TEMP%\task_query_images\<taskNo>\`），并打印每张图片的完整路径。

**查询完成后，必须用 Read 工具读取脚本打印的所有图片路径，理解其内容后再进行分析。** 图片通常包含报错截图、UI 原型、流程图等关键信息，不可跳过。

示例：
```
Read <脚本输出的图片路径>
```
