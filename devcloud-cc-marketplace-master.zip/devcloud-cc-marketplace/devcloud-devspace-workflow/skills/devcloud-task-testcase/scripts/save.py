#!/usr/bin/env python3
"""保存测试用例到任务单
用法: python3 save.py <taskNo> <projectId> <json-file>
"""

import sys
import os
import json
import urllib.request
import urllib.error


_TOKEN_MISSING = """
⚠️  未检测到研发云 Token，无法调用 API。

请按以下步骤配置后重试：

  1. 获取 Token：研发云 → 开放平台 → 我的 Token → 申请统一 Token

  2. 配置环境变量：

     Mac / Linux:
       export DEVCLOUD_TOKEN="your-token-here"    # 临时生效（仅当前终端）

       # 永久生效（写入 ~/.zshrc）——设置后需完全退出并重启 Claude Code 客户端才能识别
       echo 'export DEVCLOUD_TOKEN="your-token-here"' >> ~/.zshrc && source ~/.zshrc

     Windows PowerShell:
       $env:DEVCLOUD_TOKEN = "your-token-here"    # 临时生效（仅当前 PowerShell 窗口）

       # 永久生效（写入注册表）——设置后需完全退出并重启 Claude Code 客户端才能识别
       [Environment]::SetEnvironmentVariable("DEVCLOUD_TOKEN", "your-token-here", "User")

  注意：测试用例回填还需要配置员工号：
       export DEVCLOUD_USER_CODE="your-user-code"   # 例如 0027029669
"""


def main():
    if len(sys.argv) < 4:
        print("错误: 参数不足", file=sys.stderr)
        print("用法: python3 save.py <taskNo> <projectId> <json-file>", file=sys.stderr)
        sys.exit(1)

    task_no, project_id, json_file = sys.argv[1], sys.argv[2], sys.argv[3]
    cloudtest_api_base = os.environ.get('CLOUDTEST_API_BASE',
                                        'https://dev.iwhalecloud.com/portal/ai-gateway/cloudtest/rpc/v3')
    token = os.environ.get('DEVCLOUD_TOKEN', '')

    if not token:
        print(_TOKEN_MISSING, file=sys.stderr)
        sys.exit(1)

    if not os.path.isfile(json_file):
        print(f"错误: JSON 文件不存在: {json_file}", file=sys.stderr)
        sys.exit(1)

    with open(json_file, 'r', encoding='utf-8') as f:
        payload = f.read().encode('utf-8')

    url = f"{cloudtest_api_base}/tm/plan/case/add/rela"
    print(f"正在保存测试用例到任务单 {task_no}...")
    print(f"API: {url}")
    print(f"projectId: {project_id}")
    print(f"数据文件: {json_file}")

    req = urllib.request.Request(url, data=payload, headers={
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json'
    })

    try:
        with urllib.request.urlopen(req) as resp:
            body = json.loads(resp.read().decode('utf-8'))
            http_code = resp.status
    except urllib.error.HTTPError as e:
        body = json.loads(e.read().decode('utf-8'))
        http_code = e.code

    print(f"\nHTTP 状态码: {http_code}\n")
    print(json.dumps(body, ensure_ascii=False, indent=2))

    code = str(body.get('code', ''))
    if code == '9999':
        print(f"\n✅ 测试用例保存成功！")
    else:
        msg = body.get('msg') or body.get('message') or '未知错误'
        print(f"\n❌ 测试用例保存失败: {msg}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
