---
name: devcloud-task-testcase
description: 为任务单生成测试用例并回填到研发云。基于需求描述 + HLD 验收标准生成手工测试用例，用户审阅后推送至 cloudtest API。
---

# 任务单测试用例生成工作流

当用户需要为任务单生成测试用例时使用此技能。

## 前置检查：环境变量

调用脚本前，先执行以下命令确认必要变量已配置：

```bash
python3 -c "import os; t=os.environ.get('DEVCLOUD_TOKEN',''); u=os.environ.get('DEVCLOUD_USER_CODE',''); print('TOKEN:', t[:len(t)//2]+'****' if t else '(未设置)'); print('USER_CODE:', u[:len(u)//2]+'****' if u else '(未设置)')"
```

**若任一变量输出 `(未设置)`，停止并提示用户完成配置后再继续：**

> ⚠️ 以下环境变量未配置，请先设置：
>
> ```bash
> # 临时设置（重开终端后失效）
> export DEVCLOUD_TOKEN="your-token-here"
> export DEVCLOUD_USER_CODE="your-user-code"   # 员工号，例如 0027029669
>
> # 永久写入 ~/.zshrc
> echo 'export DEVCLOUD_TOKEN="your-token-here"' >> ~/.zshrc
> echo 'export DEVCLOUD_USER_CODE="your-user-code"' >> ~/.zshrc
> source ~/.zshrc
> ```
>
> Token 获取：研发云 → 开放平台 → 我的 Token → 申请统一 Token
>
> ⚠️ 永久写入配置文件后，需完全退出并重启 Claude Code 客户端才能生效。

确认变量已设置后继续执行。

## 触发场景

- 用户说"生成 XXX 任务单的测试用例"
- 用户说"给 XXX 创建测试用例"
## 完整流程

### 第一步：查询任务详情（条件执行）

**若当前会话中已通过 `devcloud-task-dev` 工作流查询过任务详情**（即内存中已有任务标题、需求描述、HLD 验收标准、projectId），跳过此步，直接使用已有信息进入第二步。

**仅在独立运行时**（非 devcloud-task-dev 工作流触发，或会话续接后无上下文），才需要调用 `devcloud-task-query`：

```bash
/devcloud-task-query <taskNo>
```

获取任务标题、需求描述、HLD 文档（含验收标准）、projectId 等基本信息。

### 第二步：生成测试用例

综合任务描述 + HLD 验收标准，生成一组手工测试用例。

#### 用例生成原则

- **用例名称（caseName）**：使用任务标题
- **前置条件（precondition）**：描述执行用例前需要满足的状态（如已登录、已创建某数据等）
- **步骤列表（stepList）**：⚠️ **必须且只能是单元素数组**（`enterType: "text"` 模式下 API 只接受一条记录）。所有操作步骤合写在唯一元素的 `stepDesc` 中，所有预期结果合写在对应的 `result` 中，均用 `1. 2. 3. ...` 编号格式书写，用 `\n` 换行分隔。`actualResult` 留空由用户后续补充。**严禁将多个步骤拆成多条 stepList 元素**
- **用例等级（caseLevel）**：默认 P2，核心流程用例可标 P1
- **用例类型（caseType）**：默认 0（功能测试）
- **输入模式（enterType）**：`text`（文本单步骤模式）
- **备注（note）**：必填字段，不能为空，默认填"功能测试"等简短描述
- **覆盖范围**：正常场景 + 边界条件 + 异常路径，与 HLD 验收标准对齐

#### 输出示例

生成后以表格形式展示给用户审阅：

```
用例名称：XXX 功能
前置条件：已登录系统，存在有效的 XXX 数据
步骤：
  1. 打开 XXX 页面 → 预期：页面正常加载，显示 XXX
  2. 输入 XXX 点击提交 → 预期：提示"操作成功"，列表刷新
  3. 输入非法值提交 → 预期：提示"XXX校验失败"
```

### 第三步：用户审阅与修改

测试用例生成后**必须停止**，将完整的用例内容展示给用户审阅。

- 明确告知用户："请审阅以上测试用例，确认无误后将回填到任务单。如有需要修改的地方请提出。"
- 根据用户反馈进行修改
- 用户确认无误后进入第四步

### 第四步：回填测试用例到任务单

用户确认后，先读取实际员工号，再将测试用例 JSON 写入临时文件，然后调用 `save.sh` 脚本保存到研发云：

```bash
# 0. 读取实际员工号（JSON 中 assignedUserCode 字段必须使用此命令的输出值，不能写 ${DEVCLOUD_USER_CODE} 字面量）
bash -c 'echo $DEVCLOUD_USER_CODE'
```

```bash
# 1. 将用例 JSON 写入临时文件（assignedUserCode 填写上一步 echo 的实际值；内容中的中文引号 "" 必须替换为「」或[]，否则 JSON 解析会失败）
Write /tmp/task_testcase_<taskNo>.json

# 2. 校验 JSON 格式（必须执行，不通过则修正后重新执行）
python3 -m json.tool /tmp/task_testcase_<taskNo>.json

# 3. 调用保存脚本
python3 ${CLAUDE_PLUGIN_ROOT}/skills/devcloud-task-testcase/scripts/save.py <taskNo> <projectId> /tmp/task_testcase_<taskNo>.json
```

**JSON 内容安全规则**：写入 JSON 的文本内容中**禁止**出现中文引号 `""`（U+201C/U+201D），必须替换为 `「」`、`[]` 或其他 ASCII 安全字符。此问题已多次导致服务端 JSON 解析失败（`Unexpected character 'ç'`）。

JSON 文件格式：

```json
{
  "projectId": <projectId>,
  "taskNo": "<taskNo>",
  "planCase": {
    "caseName": "<任务标题>",
    "assignedUserCode": "${DEVCLOUD_USER_CODE}",
    "stepList": [
      {
        "seqId": "1",
        "stepDesc": "1. 步骤一\n2. 步骤二\n3. 步骤三",
        "result": "1. 预期结果一\n2. 预期结果二\n3. 预期结果三",
        "actualResult": "",
        "status": "1"
      }
    ],
    "angle": "1",
    "caseType": "0",
    "caseState": "1",
    "caseLevel": "2",
    "caseCode": "",
    "enterType": "text",
    "precondition": "<前置条件>",
    "note": "功能测试",
    "markdownToTiptap": "N",
    "extraFieldValueDtoList": []
  }
}
```

脚本返回 `code: "9999"` 即保存成功。

---

## 执行纪律

1. **按需查询任务详情**：devcloud-task-dev 工作流内触发时复用已有上下文，独立运行时才调用 devcloud-task-query
2. **与 HLD 验收标准对齐**：每条验收标准至少对应一个用例步骤
3. **等待用户审阅**：生成用例后必须暂停，未经用户确认不得回填
4. **actualResult 留空**：不填写测试实际结果，由用户手工测试后补充
5. **用例数量适度**：通常 3-8 条步骤即可，覆盖核心流程和关键异常路径
6. **⚠️ stepList 必须是单元素数组**：`enterType: "text"` 模式下，所有步骤合并写入 `stepList[0]` 的 `stepDesc`/`result` 中，用 `\n` 分隔各步骤。拆成多条元素会导致 API 只展示第一条，其余步骤丢失