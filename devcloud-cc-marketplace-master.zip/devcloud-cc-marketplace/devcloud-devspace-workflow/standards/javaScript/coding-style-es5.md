# JavaScript(ES5) 语言编码规范（浩鲸科技 V1.19）

---

## 一、命名规则

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS001 | 推荐 | 避免单字母命名，命名应具备描述性 | 人工检查 |
| JS002 | 强制 | 使用驼峰式命名对象、函数和实例 | `camelcase` |
| JS003 | 强制 | 使用帕斯卡式命名构造函数或类 | `new-cap` |
| JS004 | 推荐 | 文件导出类时，文件名应与类名完全相同 | 人工检查 |

---

## 二、空白与格式

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS005 | 强制 | 使用 4 个空格缩进，禁止混用空格和 tab | `indent`, `no-mixed-spaces-and-tabs` |
| JS006 | 强制 | 避免在正则表达式中使用多个空格 | `no-regex-spaces` |
| JS007 | 强制 | 禁止使用 tab 键 | `no-tabs` |

---

## 三、逗号

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS008 | 强制 | 不使用行首逗号 | `comma-style` |
| JS009 | 强制 | 不使用额外的行末逗号（避免 IE 兼容问题） | `comma-dangle` |
| JS010 | 强制 | 禁止使用多个逗号声明空数组 | `no-sparse-arrays` |
| JS011 | 强制 | 避免使用逗号操作符（for 语句初始化/更新部分及括号内除外） | `no-sequences` |

---

## 四、分号

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS012 | 强制 | 语句以分号结束，禁止省略分号 | `no-unexpected-multiline`, `semi` |
| JS013 | 强制 | 不允许使用多余的分号 | `no-extra-semi` |

---

## 五、变量

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS014 | 强制 | 变量名采用驼峰法则，首字母小写 | `camelcase` |
| JS015 | 强制 | 始终使用 `var` 声明变量，避免产生全局变量 | `no-undef` |
| JS016 | 强制 | 使用 `var` 声明每一个变量，每行只声明一个变量 | `one-var`, `one-var-declaration-per-line` |
| JS017 | 推荐 | 最后声明未赋值的变量 | 人工检查 |
| JS018 | 强制 | 在作用域顶部声明函数，避免函数声明提升问题 | `no-inner-declarations` |
| JS019 | 强制 | 禁止重复声明变量 | `no-redeclare` |
| JS020 | 强制 | 禁止修改全局对象或只读全局对象 | `no-global-assign` |
| JS021 | 强制 | 禁止在循环语句中编写函数（避免闭包问题） | `no-loop-func` |
| JS022 | 强制 | 禁止尤达条件（字面量不能在比较操作符左边） | `yoda` |
| JS023 | 强制 | 禁止用 `delete` 删除 `var` 声明的变量 | `no-delete-var` |
| JS024 | 强制 | 禁止创建与作用域内变量同名的标签 | `no-label-var` |
| JS025 | 强制 | 禁止声明与外层作用域变量同名的变量 | `no-shadow` |
| JS026 | 强制 | 禁止声明变量时覆盖 JavaScript 保留关键字 | `no-shadow-restricted-names` |
| JS027 | 强制 | 禁止使用未定义的变量 | `no-undef` |
| JS028 | 强制 | 禁止将变量初始化为 `undefined` | `no-undef-init` |
| JS029 | 强制 | 不允许定义了变量但未使用 | `no-unused-vars` |
| JS030 | 强制 | 禁止使用链式赋值表达式 | `no-multi-assign` |
| JS031 | 强制 | 禁止在变量定义之前使用它们 | `no-use-before-define` |

---

## 六、对象

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS032 | 强制 | 使用对象字面量 `{}` 创建对象，禁止 `new Object()` | `no-new-object` |
| JS033 | 强制 | 链式调用时使用 `.` 前置缩进，`.` 与属性保持同一行 | `dot-location`, `newline-per-chained-call` |
| JS034 | 强制 | 不允许对象字面量中出现重复键名 | `no-dupe-keys` |
| JS035 | 强制 | 禁止将全局对象（Math、JSON）作为函数调用 | `no-obj-calls` |
| JS036 | 强制 | 禁止使用 `arguments.callee` | `no-restricted-properties` |
| JS037 | 强制 | 不使用保留字作为键名（IE8 不兼容） | `no-shadow-restricted-names` |

---

## 七、数组

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS038 | 强制 | 使用数组字面量 `[]` 创建数组，禁止 `new Array()` 和 `new` 包装实例 | `no-new-wrappers`, `no-array-constructor` |
| JS039 | 推荐 | 向数组增加元素时使用 `Array#push` | 人工检查 |
| JS040 | 推荐 | 拷贝数组时使用 `Array#slice` | 人工检查 |
| JS041 | 推荐 | 使用 `Array#slice` 将类数组对象转换成数组 | 人工检查 |
| JS042 | 强制 | 禁止使用 for-in 语句枚举数组 | `no-restricted-syntax` |

---

## 八、字符串

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS043 | 强制 | 使用单引号 `''` 包裹字符串 | `quotes` |
| JS044 | 推荐 | 程序化生成字符串使用 `Array#join` 连接而不是连接符 | 人工检查 |
| JS045 | 强制 | 禁止字符串分两行书写 | `no-multi-str` |
| JS046 | 强制 | 禁止不必要的字符串拼接 | `no-useless-concat` |

---

## 九、函数

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS047 | 强制 | 不在非函数代码块（if/while 等）中声明函数 | `no-inner-declarations` |
| JS048 | 强制 | 永远不要把参数命名为 `arguments` | `no-shadow-restricted-names` |
| JS049 | 强制 | 有分支时，所有 return 语句要么都指定返回值，要么都不指定 | `consistent-return` |
| JS050 | 强制 | 禁止出现空函数（允许有注释的空函数） | `no-empty-function` |
| JS051 | 强制 | 禁止给函数参数重新赋值 | `no-param-reassign` |
| JS052 | 强制 | 立即执行函数（IIFE）需要通过圆括号包围 | `wrap-iife` |
| JS053 | 强制 | 不允许函数参数使用相同的参数名 | `no-dupe-args` |
| JS054 | 强制 | 函数声明书写的函数不允许被重写或重新赋值 | `no-func-assign` |
| JS055 | 强制 | 调用不带参的构造函数时必须加圆括号 | `new-parens` |
| JS056 | 强制 | 禁止不严格要求的函数属性名加引号 | `quote-props` |

---

## 十、属性

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS057 | 强制 | 直接访问属性时使用 `.` 而不是 `[]` | `dot-notation` |
| JS058 | 推荐 | 通过变量间接访问属性时使用 `[]` | 人工检查 |
| JS059 | 强制 | 声明对象属性时只能一行声明所有属性或每行声明一个属性 | `object-property-newline` |
| JS060 | 强制 | 禁止使用 `__proto__` 属性，改用 `Object.getPrototypeOf()` | `no-proto` |
| JS061 | 强制 | 禁止使用 `__iterator__` 属性（已过时） | `no-iterator` |

---

## 十一、运算符与等号

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS062 | **警告** | 使用 `===` 和 `!==`，禁止使用 `==` 和 `!=` | `eqeqeq` |
| JS063 | 推荐 | 使用快捷方式（如 `if (name)` 代替 `if (name !== '')` ） | 人工检查 |
| JS064 | 强制 | typeof 运算结果只与有效字符串常量比较 | `valid-typeof` |
| JS065 | 强制 | 避免出现与本身作比较的语句 | `no-self-compare` |
| JS066 | 强制 | 禁止对关系运算符的左操作数使用否定运算符 | `no-unsafe-negation` |
| JS067 | 强制 | 禁止使用位运算符 | `no-bitwise` |
| JS068 | 强制 | 禁止混合使用不同的运算符（用括号明确优先级） | `no-mixed-operators` |
| JS069 | 强制 | 禁止嵌套三元运算符 | `no-nested-ternary` |
| JS070 | 强制 | 禁止不必要的三元运算符 | `no-unneeded-ternary` |
| JS071 | 推荐 | 尽可能使用赋值运算符的简写形式（`+=` 等） | `operator-assignment` |

---

## 十二、块与控制流

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS072 | 强制 | if/for 等语句的执行语句无论多少都用 `{}` 包裹 | `curly` |
| JS073 | 强制 | `else` 放在 `if` 代码块关闭括号的同一行 | `brace-style` |
| JS074 | 强制 | 避免代码中出现空的代码块 | `no-empty` |
| JS075 | 强制 | 不允许重写通过 catch 代码块捕获到的错误 | `no-ex-assign` |
| JS076 | 强制 | 禁止带有循环或 switch 语句的标签，及 break/continue 配合标签使用 | `no-labels` |
| JS077 | 强制 | 禁止不必要的嵌套块 | `no-lone-blocks` |
| JS078 | 强制 | 禁止在 `finally` 语句块中出现 return/throw/break/continue | `no-unsafe-finally` |
| JS079 | 强制 | `else` 中只有 if 语句时使用 `else if` | `no-lonely-if` |
| JS080 | 强制 | `switch` 必须有 `default` 分支（无需时加注释说明） | `default-case` |
| JS081 | 强制 | for-in 循环中必须使用 `hasOwnProperty` 过滤原型链属性 | `guard-for-in` |
| JS082 | 强制 | case/default 中使用函数声明需用 `{}` 块包装 | `no-case-declarations` |
| JS083 | 强制 | if 中有 return 之后不使用 else | `no-else-return` |
| JS084 | 强制 | 禁止不必要的 `.bind()` 调用 | `no-extra-bind` |
| JS085 | 强制 | 禁止不必要的标签 | `no-extra-label` |
| JS086 | 强制 | 禁止 case 语句落空（未显式终止） | `no-fallthrough` |
| JS087 | 强制 | 浮点小数不能省略小数点前后的数字 | `no-floating-decimal` |
| JS088 | 强制 | return 语句中不能有赋值表达式 | `no-return-assign` |
| JS089 | 强制 | 禁止在代码中使用 `alert`、`confirm`、`prompt`、`console`、`debugger` | `no-alert`, `no-console`, `no-debugger` |
| JS090 | 强制 | 禁止使用 `arguments.caller` 或 `arguments.callee` | `no-caller` |
| JS091 | 强制 | 禁止使用 `eval()` 或类似 eval 的方法（`setTimeout` 字符串参数等） | `no-eval`, `no-implied-eval`, `no-script-url` |
| JS092 | 强制 | 禁止使用 `void` 方法 | `no-void` |
| JS093 | 强制 | throw 语句必须抛出 Error 对象 | `no-throw-literal` |
| JS094 | 强制 | 禁止自我赋值 | `no-self-assign` |
| JS095 | 强制 | 禁止使用八进制数字和八进制转义序列 | `no-octal`, `no-octal-escape` |
| JS096 | 强制 | 禁止出现没有被使用到的表达式、值或标签 | `no-unused-expressions`, `no-unused-labels` |
| JS097 | 强制 | 禁止不必要的转义 | `no-useless-escape` |
| JS098 | 强制 | 禁止没有必要的 return（后面没有语句） | `no-useless-return` |
| JS099 | 强制 | 单行最大长度为 150 | `max-len` |
| JS100 | 强制 | 禁止使用 `with` 语句 | `no-with` |

---

## 十三、注释

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS101 | 推荐 | 注释应有意义，重点解释不容易立即明白的逻辑 | 人工检查 |
| JS102 | 推荐 | 函数头注释使用 `/** ... */` 多行注释，包含描述、参数和返回值类型 | 人工检查 |
| JS103 | 强制 | 使用 `//` 单行注释，注释在对象上方另起一行，块注释前插入空行 | `lines-around-comment` |
| JS104 | 推荐 | 使用 `// FIXME:` 标注问题，使用 `// TODO:` 标注解决方式 | `no-warning-comments` |

---

## 十四、类型转换

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS105 | 推荐 | 在语句开始时执行类型转换（字符串转换置于前面） | 人工检查 |
| JS106 | 强制 | 使用 `parseInt` 时必须指定第二个参数（进制基数） | `radix` |
| JS107 | 推荐 | 布尔转换使用 `Boolean(age)` 或 `!!age`，不用 `new Boolean()` | 人工检查 |

---

## 十五、构造函数

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS108 | 强制 | 给对象原型分配方法，而不是用新对象覆盖原型 | 人工检查 |
| JS109 | 强制 | 禁止业务代码修改内置对象（Object/Array/Function）的原型对象 | 人工检查 |

---

## 十六、事件

| 编号 | 级别 | 规范 | ESLint 规则 |
|------|------|------|------------|
| JS110 | 推荐 | 给事件附加数据时传入对象而不是原始值，便于后续扩展 | 人工检查 |

---

## 十七、安全

| 编号 | 级别 | 规范 | 说明 |
|------|------|------|------|
| JS111 | 强制 | 不要使用 `Math.random()` 生成随机数，使用 Web Crypto API 的 `crypto.getRandomValues()` | CWE-330 |
| JS112 | 强制 | HTTP 请求 Header 中设置 `X-CSRF-token` 安全头字段，防止 CSRF 漏洞 | 安全防护 |
| JS113 | 强制 | 静态资源文件更新后须版本化（版本号/哈希值命名或查询参数），避免浏览器缓存旧文件 | 故障 3765517 |
| JS114 | 强制 | 所有 HTTP 请求必须设置超时时间，禁止未配置超时的请求 | 故障 2283079 |
| JS115 | 强制 | 禁止使用 `Date.prototype.toLocaleDateString()`，使用标准化工具库代替 | 故障 21413704 |
| JS116 | 强制 | 包含重要信息（如数字签名等）的前端 js 文件必须进行混淆加固（使用研发云持续构建混淆加固节点） | 安全治理 11109465 |
| JS117 | 强制 | 前端应用 nginx 基础镜像必须使用国际业务运营中心-平台技术部提供的基础安全镜像 | 故障 3791904 |
| JS118 | 强制 | 禁止在前端 js/css/html 文件中包含物理路径、数据库连接、SQL语句、appKey/accessSecret、对象存储 key/secret、用户名密码等敏感信息 | 安全防护 |
