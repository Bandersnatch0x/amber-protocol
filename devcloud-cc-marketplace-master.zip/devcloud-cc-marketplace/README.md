# DevCloud CC 插件市场

浩鲸研发云 Claude Code 插件市场，汇集公司内部开发工作流插件。

> 详细使用说明请参阅 [USAGE.md](./USAGE.md)

## 添加此市场

在 Claude Code 中执行：

```bash
/plugin marketplace add https://git-nj.iwhalecloud.com/icicd/devcloud-cc-marketplace.git
```

添加后执行 `/plugin` 即可浏览和安装市场中的插件。

---

## 插件列表

### devcloud-devspace-workflow

任务单开发全流程工作流插件，提供从查询、HLD生成、计划制定、TDD开发到静态检查、测试用例回填的完整 10 步流程。

**前置依赖**：依赖 superpowers 插件（提供验证、代码走查等基础能力）。

```bash
# 先安装前置依赖
/plugin install superpowers@claude-plugins-official

# 再安装本插件
/plugin install devcloud-devspace-workflow@devcloud-marketplace
```

**使用方式**：

```bash
/devcloud-task-dev <任务单号>
```

工作流按序执行：查询详情 → 生成 HLD 回填 → 制定计划 → 确认计划 → 执行开发 → 验证交付 → 生成测试用例回填 → 用户本地验证 → Harness 回顾 → 交互统计。

**首次使用需配置环境变量**（写入 `~/.bashrc` 或 `~/.zshrc`）：

```bash
# 研发云 API Token（必填）
# Token 获取：研发云 → 开放平台 → 我的 Token → 申请统一 Token
export DEVCLOUD_TOKEN="your-token-here"

# 默认用户编码（必填，测试用例回填时需要）
export DEVCLOUD_USER_CODE="your-user-code"

# ⚠️ 写入 ~/.zshrc 后需完全退出并重启 Claude Code 客户端才能生效

# API 地址（可选，默认值为开发环境地址）
# export DEVCLOUD_API_BASE="https://dev.iwhalecloud.com/portal/ai-gateway/devspace/rpc/v3"
# export CLOUDTEST_API_BASE="https://dev.iwhalecloud.com/portal/ai-gateway/cloudtest/rpc/v3"
```

同时需在项目中准备规则文件和知识图谱（详见下方「项目接入要求」）。

**包含的 Skill**：

| Skill | 说明 |
|-------|------|
| `devcloud-task-dev` | 主编排器，10 步开发工作流 |
| `devcloud-task-query` | 查询研发云任务单信息（含图片下载） |
| `devcloud-task-hld` | 生成 HLD 文档并回填到任务单 |
| `devcloud-task-testcase` | 生成测试用例并回填到 cloudtest |
| `devcloud-pre-delivery-check` | 交付前静态检查（subagent 模式） |
| `devcloud-harness-review` | Harness 回顾，持续改进规则 |
| `devcloud-java-tdd` | Java TDD 红绿重构开发流程 |

---

## 项目接入要求

各项目接入插件前，需在项目中按需准备以下内容：

### 1. 规则文件（`.claude/rules/`）

**规则文件由各项目自行维护**，文件名可自由命名，按目录分类即可。以下为推荐结构：

```
<项目根目录>/
├── .claude/
│   ├── rules/
│   │   ├── common/
│   │   │   ├── git-operations.md            # Git 操作约束
│   │   │   ├── business-scope.md            # 业务范围约束
│   │   │   └── feedback-interpretation.md   # 用户反馈解读
│   │   ├── backend/
│   │   │   ├── xxx-architecture.md          # 分层架构规范
│   │   │   ├── xxx-naming.md                # 命名规范
│   │   │   ├── xxx-coding-style.md          # 编码风格
│   │   │   └── xxx-constraints.md           # 技术/性能/安全约束
│   │   └── frontend/
│   │       ├── xxx-architecture.md          # 前端架构总览
│   │       └── xxx-conventions.md           # 通用规范
│   └── standards/                           # 项目补充规范（可选）
│       └── ...                              # 插件已自带公司级规范，此处只放项目特有补充
└── doc/
    └── knowledge_map/                       # 项目业务知识图谱（可选）
        ├── index.md
        └── spec/
            └── *.md
```

> **公司级编码规范**（Java 编码风格、安全规范、JS 编码规范等）已内置在插件中，无需项目手动配置。项目可通过 `.claude/standards/` 目录添加项目特有的补充规范。
>
> **知识图谱**为可选配置。默认从 `doc/knowledge_map/` 加载，可通过环境变量自定义路径：
>
> ```bash
> export KNOWLEDGE_MAP_PATH="docs/knowledge-graph"   # 自定义路径（可选）
> ```
>
> 若知识图谱目录不存在，相关 skill 会自动跳过知识图谱环节，不会中断工作流。

### 2. JDK 21

确保 `JAVA_HOME` 指向 JDK 21（TDD 开发需要）：

```bash
java -version
# Mac 设置
export JAVA_HOME=$(/usr/libexec/java_home -v 21)
```

---

## 如何在此市场添加新插件

### 方式一：放入本仓库

将新插件代码放到本仓库的独立子目录中，然后在 `marketplace.json` 的 `plugins` 数组中新增一项。

**1. 创建插件目录**

```
devcloud-cc-marketplace/
├── devcloud-devspace-workflow/       # 已有插件
│   └── ...
└── devcloud-dynamic-search/          # 新插件
    ├── .claude-plugin/
    │   └── plugin.json
    └── skills/
        └── devcloud-dynamic-search/
            └── SKILL.md
```

`plugin.json` 示例：

```json
{
  "name": "devcloud-dynamic-search",
  "version": "1.0.0",
  "description": "前端动态搜索下拉组件实现模板",
  "author": { "name": "...", "email": "..." },
  "keywords": ["frontend", "dynamic-search"]
}
```

**2. 更新 marketplace.json**

```json
{
  "plugins": [
    {
      "name": "devcloud-devspace-workflow",
      "source": "./devcloud-devspace-workflow"
    },
    {
      "name": "devcloud-dynamic-search",
      "description": "前端动态搜索下拉组件实现模板",
      "category": "development",
      "source": "./devcloud-dynamic-search"
    }
  ]
}
```

提交推送后，已添加此市场的用户执行 `/plugin` 即可看到新插件。

### 方式二：引用外部仓库

不把代码放到本仓库，只在此做索引：

```json
{
  "name": "other-teams-plugin",
  "description": "其他团队的插件",
  "source": {
    "source": "url",
    "url": "https://git-nj.iwhalecloud.com/other-team/their-plugin.git"
  }
}
```

---

## License

UNLICENSED - 内部使用
