# DevCloud 插件市场使用说明

## 方式一：通过插件市场安装（推荐）

### 1. 添加市场

在 Claude Code 中执行：

```bash
/plugin marketplace add https://git-nj.iwhalecloud.com/icicd/devcloud-cc-marketplace.git
```

### 2. 安装插件

```bash
# 先安装前置依赖
/plugin install superpowers@claude-plugins-official

# 再安装本插件
/plugin install devcloud-devspace-workflow@devcloud-marketplace
```

### 3. 配置环境变量

将以下配置写入 `~/.bashrc` 或 `~/.zshrc`：

```bash
# 研发云 API Token（必填）
# Token 获取：研发云 → 开放平台 → 我的 Token → 申请统一 Token
export DEVCLOUD_TOKEN="your-token-here"

# 默认用户编码（必填，测试用例回填时需要）
export DEVCLOUD_USER_CODE="your-user-code"

# 知识图谱路径（可选，默认为 doc/knowledge_map）
# export KNOWLEDGE_MAP_PATH="docs/knowledge-graph"

# API 地址（可选，默认值为开发环境地址）
# export DEVCLOUD_API_BASE="https://dev.iwhalecloud.com/portal/ai-gateway/devspace/rpc/v3"
# export CLOUDTEST_API_BASE="https://dev.iwhalecloud.com/portal/ai-gateway/cloudtest/rpc/v3"
```

> **注意**：写入 `~/.zshrc` 后需完全退出并重启 Claude Code 客户端才能生效。

### 4. 项目接入准备

在项目根目录准备以下内容：

#### 4.1 规则文件（`.claude/rules/`）

推荐目录结构：

```
<项目根目录>/
├── .claude/
│   ├── rules/
│   │   ├── common/
│   │   │   ├── git-operations.md            # Git 操作约束
│   │   │   ├── business-scope.md            # 业务范围约束
│   │   │   └── feedback-interpretation.md   # 用户反馈解读
│   │   ├── backend/
│   │   │   ├── xxx-architecture.md          # 分层架构规范
│   │   │   ├── xxx-naming.md                # 命名规范
│   │   │   ├── xxx-coding-style.md          # 编码风格
│   │   │   └── xxx-constraints.md           # 技术/性能/安全约束
│   │   └── frontend/
│   │       ├── xxx-architecture.md          # 前端架构总览
│   │       └── xxx-conventions.md           # 通用规范
│   └── standards/                           # 项目补充规范（可选）
│       └── ...
└── doc/
    └── knowledge_map/                       # 项目业务知识图谱（可选）
        ├── index.md
        └── spec/
            └── *.md
```

#### 4.2 JDK 21（TDD 开发需要）

```bash
java -version
# Mac 设置
export JAVA_HOME=$(/usr/libexec/java_home -v 21)
```

### 5. 使用

```bash
/devcloud-task-dev <任务单号>
```

工作流按序执行：查询详情 → 生成 HLD 回填 → 制定计划 → 确认计划 → 执行开发 → 验证交付 → 生成测试用例回填 → 用户本地验证 → Harness 回顾 → 交互统计。

**可用的 Skill：**

| Skill | 说明 |
|-------|------|
| `devcloud-task-dev` | 主编排器，10 步开发工作流 |
| `devcloud-task-query` | 查询研发云任务单信息（含图片下载） |
| `devcloud-task-hld` | 生成 HLD 文档并回填到任务单 |
| `devcloud-task-testcase` | 生成测试用例并回填到 cloudtest |
| `devcloud-pre-delivery-check` | 交付前静态检查（subagent 模式） |
| `devcloud-harness-review` | Harness 回顾，持续改进规则 |
| `devcloud-java-tdd` | Java TDD 红绿重构开发流程 |

---

## 方式二：自行下载 Skill 到本地使用

如果不通过插件市场安装，也可以直接下载 Skill 文件到本地项目中手动使用。

### 1. 克隆仓库

```bash
git clone https://git-nj.iwhalecloud.com/icicd/devcloud-cc-marketplace.git
```

### 2. 复制所需 Skill 到本地 `.claude/` 目录

根据实际需要，将对应的 Skill 目录复制到当前项目的 `.claude/skills/` 下：

```bash
# 进入你的项目根目录
cd <your-project>

# 创建 skills 目录
mkdir -p .claude/skills

# 复制所需 skill（以 devcloud-task-dev 为例）
cp -r /path/to/devcloud-cc-marketplace/devcloud-devspace-workflow/skills/devcloud-task-dev .claude/skills/

# 按需复制其他 skill
cp -r /path/to/devcloud-cc-marketplace/devcloud-devspace-workflow/skills/devcloud-task-query .claude/skills/
cp -r /path/to/devcloud-cc-marketplace/devcloud-devspace-workflow/skills/devcloud-task-hld .claude/skills/
cp -r /path/to/devcloud-cc-marketplace/devcloud-devspace-workflow/skills/devcloud-task-testcase .claude/skills/
cp -r /path/to/devcloud-cc-marketplace/devcloud-devspace-workflow/skills/devcloud-pre-delivery-check .claude/skills/
cp -r /path/to/devcloud-cc-marketplace/devcloud-devspace-workflow/skills/devcloud-harness-review .claude/skills/
cp -r /path/to/devcloud-cc-marketplace/devcloud-devspace-workflow/skills/devcloud-java-tdd .claude/skills/
```

### 3. 配置环境变量

同方式一的第 3 步，将以下配置写入 `~/.bashrc` 或 `~/.zshrc`：

```bash
export DEVCLOUD_TOKEN="your-token-here"
export DEVCLOUD_USER_CODE="your-user-code"
```

### 4. 项目接入准备

同方式一的第 4 步，准备规则文件和知识图谱。

### 5. 使用

直接在 Claude Code 中通过技能名调用：

```bash
/devcloud-task-dev <任务单号>
/devcloud-task-query <任务单号>
/devcloud-task-hld <任务单号>
/devcloud-task-testcase <任务单号>
/devcloud-pre-delivery-check
/devcloud-harness-review
/devcloud-java-tdd
```

> **注意**：各 Skill 之间存在调用依赖。例如 `devcloud-task-dev` 会编排调用其他 skill，独立使用时请确保所需的下游 skill 也已复制到本地。

---